<?php

namespace App\Models;

use App\Traits\CommonScope;
use Illuminate\Database\Eloquent\Model;

class Referral extends Model
{
    use CommonScope;
}
