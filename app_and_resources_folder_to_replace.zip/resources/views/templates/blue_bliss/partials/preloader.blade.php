<div class="preloader" id="preloader">
    <div class="logo">
    </div>
    <div class="loader-frame">
        <div class="loader1" id="loader1">
        </div>
        <div class="circle"></div>
        <h6 class="wellcome">
            <span class="d-block w-100 text-white">@lang('Wellcome to')</span>
            <span class="d-block w-100">{{ $general->site_name }}</span>
        </h6>
    </div>
</div>
<a href="#0" class="scrollToTop"><i class="la la-angle-up"></i></a>
<div class="overlay"></div>
